Rails.application.routes.draw do
  # Show archive
  resources :archives, only: [:index, :show], path: 'archive'
  get "archive/:id/submission/:id", to: "forms#show", as: "show_form"

  get 'forms/:id/new', to: 'forms#new', as: 'new_form'
  resources :form_submissions, only: [:index, :show, :edit, :update], as: 'submission'

  # Organisations-Routen (Index + Show)
  resources :organisations, only: [:index, :show, :new, :create, :edit, :update, :destroy] do


    # Gruppen & Memberships weiterhin nested
    resources :groups do
      member do
        post   "add_member",       action: :add_member,    as: :add_member
        delete "remove_member/:user_id", action: :remove_member, as: :remove_member
      end
    end
    resources :memberships, only: [:create, :destroy, :update]

    # (optional) Flows nested, wenn du deine Flows wirklich unter Organisationen verwaltest:
    resources :flows, only: [:new, :create]
  end

  # Wenn du Flows auch global anschauen/bearbeiten willst:
  resources :flows, only: [:index, :new, :create, :show, :edit, :update, :destroy]


  devise_for :users, controllers: {
    registrations: "users/registrations",
    sessions:      "users/sessions"
  }

  resource :profile, only: [:show, :edit, :update]

  authenticated :user do
    root "home#index", as: :authenticated_root
  end

  get 'home', to: 'home#index', as: :home
  root "home#index"

  resources :forms do
    resources :fields
  end

  get "up" => "rails/health#show", as: :rails_health_check
end 