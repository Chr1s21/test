#!/bin/bash
set -e

# Remove any old Rails server.pid file
rm -f /app/tmp/pids/server.pid

# Pass control to whatever command is passed to the container
exec "$@"
