import { Controller } from "@hotwired/stimulus";

export default class extends Controller {
  connect() {
    console.log("FormBuilder connected");
    if (window.jQuery) {
      this.initializeDraggable();
      this.restorePositions();
      this.initializeAddByDrop();
      this.initializeInputHandling();
    } else {
      document.addEventListener("DOMContentLoaded", () => {
        this.initializeDraggable();
        this.restorePositions();
        this.initializeAddByDrop();
        this.initializeInputHandling();
      });
    }
  }

  initializeDraggable() {
    $("#snaptarget .drag").draggable({
      snap: true,
      grid: [10, 10],
      containment: "#snaptarget",
      scroll: true, 
      scrollSensitivity: 100, 
      scrollSpeed: 20,
      start: (event, ui) => {
        $("#trash-bin").removeClass("hidden").addClass("active");
        $(ui.helper).css("z-index", 100);
      },
      drag: (event, ui) => {
        const isColliding = this.isColliding(ui.helper, ui.helper.position());
        if (isColliding) {
          ui.helper.addClass("collision-detected");
        } else {
          ui.helper.removeClass("collision-detected");
        }

        ui.position.left = Math.round(ui.position.left / 10) * 10;
        ui.position.top = Math.round(ui.position.top / 10) * 10;
      },

      stop: (event, ui) => {
        const $element = $(ui.helper);
        // Collision-Handling
        $("#trash-bin").removeClass("active highlight").addClass("hidden");
        
        if (this.isColliding($element, $element.position())) {
          const originalPos = ui.originalPosition;
          $element.animate(
            {
              left: originalPos.left,
              top: originalPos.top,
            },
            300,
            () => {
              $element.removeClass("collision-detected");
              return;
            }
          );
          return;
        }
        const left = Math.round($element.position().left / 10) * 10;
        const top = Math.round($element.position().top / 10) * 10;

        $element.css({
          left: left,
          top: top,
        });

        this.ensureWithinContainer($element);
        this.updatePositions();
      },
    });

    $("#trash-bin").droppable({
      accept: ".drag", 
      tolerance: "pointer",
      over: function(event, ui) {
        $(this).addClass("highlight");
      },
      out: function(event, ui) {
        $(this).removeClass("highlight");
      },
      drop: function(event, ui) {
        console.log("Dropped on trash bin!");
        const $element = ui.draggable;
        const fieldId = $element.data("id");
        const formId = document.querySelector("#main-form").dataset.formId;
        
        
        
        if (fieldId && formId) {
          fetch(`/forms/${formId}/fields/${fieldId}`, {
            method: "DELETE",
            headers: {
              "X-CSRF-Token": document.querySelector('meta[name="csrf-token"]').content,
              Accept: "application/json",
            },
          })
          .then((response) => {
            if (!response.ok) {
              throw new Error("Network response was not ok");
            }
            return response.json();
          })
          .then((data) => {
            $element.remove();
            $(this).removeClass("highlight active")
            this.updatePositions();
            this.showNotice("Field deleted successfully", "success");
          })
          .catch((error) => {
            console.error("Error deleting field:", error);
            this.showNotice("Error deleting field. Please try again.", "error");
          });
        }
      }.bind(this) 
    });
    this.initializePositions();
  }

  initializeAddByDrop() {
    const $ = window.jQuery;
    const that = this;
    const formId =
      this.element.dataset.formBuilderId ||
      document.querySelector("#main-form").dataset.formId;

    $(".field-template").draggable({
      helper: "clone",
      appendTo: "body",
      zIndex: 1000,
      revert: "invalid",
      cursor: "grabbing",
      start: function (event, ui) {
        $(ui.helper).css({
          width: "208px",
          height: "100px",
          "background-color": "#f0f8ff",
          border: "2px dashed #1e40af",
          "border-radius": "0.25rem",
          opacity: "0.8",
          "z-index": "1000",
          "box-shadow": "0 5px 15px rgba(0, 0, 0, 0.2)",
          display: "flex",
          "align-items": "center",
          "justify-content": "center",
        });

        const fieldType = $(this).data("field-type");
        $(ui.helper).text(
          `New ${fieldType.charAt(0).toUpperCase() + fieldType.slice(1)} Field`
        );
      },
    });

    $("#snaptarget").droppable({
      accept: ".field-template",
      tolerance: "pointer",

      drop: function (event, ui) {
        const dropPosition = {
          left: ui.offset.left - $(this).offset().left + $(this).scrollLeft(),
          top: ui.offset.top - $(this).offset().top + $(this).scrollTop(),
        };

        // Snap to grid
        dropPosition.left = Math.round(dropPosition.left / 20) * 20;
        dropPosition.top = Math.round(dropPosition.top / 20) * 20;

        const isPositionFree = !that.isColliding($(ui.helper), dropPosition);

        if (isPositionFree) {
          const fieldType = ui.draggable.data("field-type");
          const fieldName = ui.draggable.data("field-name");
          console.log("Add Field at position:", dropPosition);

          that.addFieldAtPosition(fieldType, fieldName, dropPosition);
        } else {
          // Zeige Kollisionsnotiz
          console.log("Position occupied");
          that.showNotice(
            "Cannot place field here - position is occupied",
            "error"
          );
        }
      },
    });
  }

  isOverTrashBin($element) {
    const $ = window.jQuery;
    const trashBin = $("#trash-bin");

    if (trashBin.length === 0) return false;

    const elementRect = {
      left: $element.offset().left,
      top: $element.offset().top,
      right: $element.offset().left + $element.outerWidth(),
      bottom: $element.offset().top + $element.outerHeight(),
    };

    const trashRect = {
      left: trashBin.offset().left,
      top: trashBin.offset().top,
      right: trashBin.offset().left + trashBin.outerWidth(),
      bottom: trashBin.offset().top + trashBin.outerHeight(),
    };

    // Prüfe, ob sich die Rechtecke überschneiden
    console.log("CHecking for trash bin collision", elementRect.right > trashRect.left &&
      elementRect.left < trashRect.right &&
      elementRect.bottom > trashRect.top &&
      elementRect.top < trashRect.bottom);
    return (
      elementRect.right > trashRect.left &&
      elementRect.left < trashRect.right &&
      elementRect.bottom > trashRect.top &&
      elementRect.top < trashRect.bottom
    );
  }

  addFieldAtPosition(fieldType, fieldName, position) {
    const formId =
      this.element.dataset.formBuilderId ||
      document.querySelector("#main-form").dataset.formId;

    fetch(`/forms/${formId}/fields`, {
      method: "POST",
      headers: {
        "X-CSRF-Token": document.querySelector('meta[name="csrf-token"]')
          .content,
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        field: {
          name: fieldName,
          field_type: fieldType,
          x_position: position.left,
          y_position: position.top,
        },
      }),
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        return response.json();
      })
      .then((data) => {
        this.appendFieldToList(data.field);
      })
      .catch((error) => {
        console.error("Error adding field:", error);
        this.showNotice("Error adding field. Please try again.", "error");
      });
  }

  initializePositions() {
    const $ = window.jQuery;
    const container = $("#snaptarget");

    $("#snaptarget .drag").each((index, element) => {
      const $element = $(element);

      // Position aus den hidden inputs auslesen
      const xPos = parseInt($element.find('[name$="[x_position]"]').val()) || 0;
      const yPos = parseInt($element.find('[name$="[y_position]"]').val()) || 0;

      // Position setzen
      $element.css({
        position: "absolute",
        left: xPos,
        top: yPos,
      });

      // Stellen Sie sicher, dass alle Elemente im Container sind
      this.ensureWithinContainer($element);
    });

    // Positionen aktualisieren
    this.updatePositions();
  }

  isColliding($element, position) {
    const $ = window.jQuery;
    let collision = false;

    // Aktuelle Element-Dimensionen
    const el = $element[0];
    const rect1 = {
      left: position.left,
      top: position.top,
      right: position.left + $element.outerWidth(),
      bottom: position.top + $element.outerHeight(),
    };

    // Gegen alle anderen Elemente prüfen
    $("#snaptarget .drag").each((i, other) => {
      const $other = $(other);

      // Das Element mit sich selbst prüfen überspringen
      if (el === other) return;

      // Position des anderen Elements
      const otherPos = $other.position();
      const rect2 = {
        left: otherPos.left,
        top: otherPos.top,
        right: otherPos.left + $other.outerWidth(),
        bottom: otherPos.top + $other.outerHeight(),
      };

      // Kollision erkennen
      if (
        rect1.left < rect2.right &&
        rect1.right > rect2.left &&
        rect1.top < rect2.bottom &&
        rect1.bottom > rect2.top
      ) {
        collision = true;
        return false; // Schleife abbrechen
      }
    });

    return collision;
  }

  isPositionOccupied(position) {
    const $ = window.jQuery;
    let occupied = false;

    const templateWidth = 208;
    const templateHeight = 120;
    const rect1 = {
      left: position.left,
      top: position.top,
      right: position.left + templateWidth,
      bottom: position.top + templateHeight,
    };

    $("#snaptarget .drag").each((i, element) => {
      const $elem = $(element);
      const pos = $elem.position();
      const rect2 = {
        left: pos.left,
        top: pos.top,
        right: pos.left + $elem.outerWidth(),
        bottom: pos.top + $elem.outerHeight(),
      };

      if (
        rect1.left < rect2.right &&
        rect1.right > rect2.left &&
        rect1.top < rect2.bottom &&
        rect1.bottom > rect2.top
      ) {
        occupied = true;
        return false;
      }
    });

    return occupied;
  }

  ensureWithinContainer($element) {
    const $ = window.jQuery;
    const container = $("#snaptarget");
    const containWidth = container.innerWidth();
    const containHeight = container.innerHeight();
    const elemWidth = $element.outerWidth();
    const elemHeight = $element.outerHeight();

    // Aktuelle Position
    let pos = $element.position();

    // Grenzen prüfen und korrigieren
    if (pos.left < 0) pos.left = 0;
    if (pos.top < 0) pos.top = 0;
    if (pos.left + elemWidth > containWidth)
      pos.left = containWidth - elemWidth;
    if (pos.top + elemHeight > containHeight)
      pos.top = containHeight - elemHeight;

    // Korrigierte Position anwenden
    $element.css({
      left: pos.left,
      top: pos.top,
    });
  }

  restorePositions() {
    const $ = window.jQuery;
    $("#snaptarget .drag").each((index, element) => {
      const xPos = $(element).find('[name$="[x_position]"]').val();
      const yPos = $(element).find('[name$="[y_position]"]').val();

      if (xPos && yPos) {
        $(element).css({
          position: "absolute",
          left: `${xPos}px`,
          top: `${yPos}px`,
        });
      }
    });
  }

  updatePositions() {
    console.log("Drag ended, updating positions");

    $("#snaptarget .drag").each((index, element) => {
      $(element)
        .find('[data-sortable-target="positionInput"]')
        .val(index + 1);

      const position = $(element).position();
      $(element).find('[name$="[x_position]"]').val(position.left);
      $(element).find('[name$="[y_position]"]').val(position.top);
    });
  }

  removeField(event) {
    event.preventDefault();

    // Get the form ID and field ID from the button's data attributes
    const formId = event.currentTarget.dataset.formid;
    const fieldId = event.currentTarget.dataset.id;

    console.log(fieldId, formId);

    if (!formId || !fieldId) {
      console.error("Missing form ID or field ID", { formId, fieldId });
      return;
    }

    // Display confirmation dialog
    // Send DELETE request to the server
    fetch(`/forms/${formId}/fields/${fieldId}`, {
      method: "DELETE",
      headers: {
        "X-CSRF-Token": document.querySelector('meta[name="csrf-token"]')
          .content,
        Accept: "application/json",
      },
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        return response.json();
      })
      .then((data) => {
        // Remove the field from the DOM
        const fieldElement = document.querySelector(
          `div[data-id="${fieldId}"]`
        );
       
        if (fieldElement) {
          fieldElement.remove();

          this.updatePositions();
        }
      })
      .catch((error) => {
        console.error("Error deleting field:", error);

        this.showNotice("Error deleting field. Please try again.", "error");
        setTimeout(() => {
          errorNotice.remove();
        }, 5000);
      });
  }

  addField(event) {
    event.preventDefault();

    const button = event.currentTarget;
    const fieldType = button.dataset.fieldType;
    const fieldName = button.dataset.fieldName;
    const formId =
      this.element.dataset.formBuilderId ||
      document.querySelector("#main-form").dataset.formId;

    fetch(`/forms/${formId}/fields`, {
      method: "POST",
      headers: {
        "X-CSRF-Token": document.querySelector('meta[name="csrf-token"]')
          .content,
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        field: {
          name: fieldName,
          field_type: fieldType,
        },
      }),
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        return response.json();
      })
      .then((data) => {
        this.appendFieldToList(data.field);
      })
      .catch((error) => {
        console.error("Error adding field:", error);
        this.showNotice("Error adding field. Please try again.", "error");
      });
  }

  appendFieldToList(field) {
    const dragtarget = document.getElementById("snaptarget");

    // if (document.getElementById("empty-list")) {
    //   document.getElementById("empty-list").remove();
    // }

    // Erstelle das neue Listenelement
    const div = document.createElement("div");
    div.setAttribute("data-id", field.id);
    div.setAttribute("draggable", "true");
    div.className =
      "flex flex-col w-52 mb-3 border-2 border-dashed p-2 border-gray-300 rounded cursor-grab drag";

    // HTML für verschiedene Feldtypen
    let fieldHtml = "";

    // Die Struktur richtet sich nach der vorhandenen Markup-Struktur
    fieldHtml = ` 
          <input type="text" name="form[fields_attributes][${field.id}][name]" 
            value="${field.name}" 
            data-form-builder-target="input" 
            data-id="${field.id}" 
            class="mb-3">
          
          ${this.getFieldInputByType(field)}
          
          <input type="hidden" name="form[fields_attributes][${
            field.id
          }][id]" value="${field.id}">
          <input type="hidden" name="form[fields_attributes][${
            field.id
          }][field_type]" value="${field.field_type}">
          <input type="hidden" name="form[fields_attributes][${
            field.id
          }][position]" 
            value="${field.position}" 
            data-sortable-target="positionInput">
          <input type="hidden" name="form[fields_attributes][${
            field.id
          }][x_position]" value="${field.x_position || 150}">
          <input type="hidden" name="form[fields_attributes][${
            field.id
          }][y_position]" value="${field.y_position || 150}">
       
      `;

    div.innerHTML = fieldHtml;
    dragtarget.appendChild(div);
    div.innerHTML = fieldHtml;
    dragtarget.appendChild(div);

    this.initializeDraggable();
    this.initializeDraggable();
    this.updatePositions();
  }

  getFieldInputByType(field) {
    let inputHtml = "";

    switch (field.field_type) {
      case "text":
        inputHtml = `
            <input type="text" placeholder="Enter Text" readonly="true" class="p-2 border bg-white border-gray-300 rounded">
            <input type="hidden" name="form[fields_attributes][${
              field.id
            }][value]" value="${field.value || ""}">
          `;
        break;
      case "number":
        inputHtml = `
            <input type="number" placeholder="Enter Number" readonly="true" class="p-2 border bg-white border-gray-300 rounded w-full">
            <input type="hidden" name="form[fields_attributes][${
              field.id
            }][value]" value="${field.value || ""}">
          `;
        break;
      case "checkbox":
        inputHtml = `
            <div>
              <input type="checkbox" onclick="return false;" class="p-2 border bg-white border-gray-300 rounded">
            </div>
            <input type="hidden" name="form[fields_attributes][${
              field.id
            }][value]" value="${field.value || ""}">
          `;
        break;
      case "date":
        inputHtml = `
            <input type="date" placeholder="" readonly="true" class="p-2 border bg-white border-gray-300 rounded w-48">
            <input type="date" placeholder="" readonly="true" class="p-2 border bg-white border-gray-300 rounded w-48">
            <input type="hidden" name="form[fields_attributes][${
              field.id
            }][value]" value="${field.value || ""}">
          `;
        break;
    }

    return inputHtml;
  }

  showNotice(message, type) {
    const notice = document.createElement("div");
    if (type === "success") {
      notice.className =
        "bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded my-2 absolute left-1/2 transform -translate-x-1/2";
    } else {
      notice.className =
        "bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded my-2 absolute left-1/2 transform -translate-x-1/2";
    }
    notice.textContent = message;

    const container = document.querySelector(".form-fields-container");
    container.prepend(notice);

    setTimeout(() => {
      notice.remove();
    }, 1500);
  }

  initializeInputHandling() {
    $(document).on('mousedown', '.drag input', function(e) {
      e.stopPropagation();
    });
    
    $(document).on('dragstart', '.drag input', function(e) {
      e.preventDefault();
      e.stopPropagation();
      return false;
    });
    
    $(document).on('focus', '.drag input', function(e) {
      $(this).closest('.drag').attr('draggable', 'false');
      
      const input = this;
      const length = input.value.length;
      
      // Browser kompatibility
      setTimeout(() => {
        input.setSelectionRange(length, length);
        input.focus();
      }, 0);
    });
    
    $(document).on('blur', '.drag input', function(e) {
      $(this).closest('.drag').attr('draggable', 'true');
    });
    
    // Positioning coursor
    $(document).on('click', '.drag input', function(e) {
      e.stopPropagation();
      
      const input = this;
      const length = input.value.length;
      
      if (!$(input).is(':focus')) {
        setTimeout(() => {
          input.setSelectionRange(length, length);
        }, 0);
      }
    });
    
    $(document).on('keydown', '.drag input', function(e) {
      e.stopPropagation();
    });
  }
}
