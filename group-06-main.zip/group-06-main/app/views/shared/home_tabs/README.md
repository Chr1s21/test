# Dashboard Partials Documentation

This directory contains partials used for the dashboard tab system on the home page. These partials work together to create a modular, maintainable dashboard interface.

## Partial Components

### `_user_welcome.html.erb`

**Purpose:** Displays the user greeting and logout button at the top of the dashboard.

- ✅ Shows personalized welcome with user's first name
- ✅ Contains the logout button
- ✅ Displays welcome message

### `_tab_button.html.erb`

**Purpose:** Renders an individual tab button in the dashboard navigation.

- ✅ Takes a `tab` parameter with tab configuration
- ✅ Handles active state styling
- ✅ Shows count or empty message based on tab data
- ✅ Configured with Alpine.js click handlers for tab switching

### `_tab_content.html.erb`

**Purpose:** Container for each tab's content area.

- ✅ Shows/hides content based on active tab (uses Alpine.js)
- ✅ Renders appropriate header and content based on tab config
- ✅ Conditionally displays custom content, item lists, or empty states
- ✅ Coordinates the rendering of appropriate child partials

### `_tab_header.html.erb`

**Purpose:** Header for each tab's content section.

- ✅ Shows section title
- ✅ Includes "View All" link to full listing page
- ✅ Maintains consistent styling across all tab sections

### `_empty_state.html.erb`

**Purpose:** Displays when a tab has no items to show.

- ✅ Shows icon, title and helper text
- ✅ Optionally displays action button (e.g., "Create Organization")
- ✅ Uses consistent empty state styling

### `_organization_item.html.erb`

**Purpose:** Card component for displaying an individual organization.

- ✅ Shows organization name and first letter
- ✅ Displays member count
- ✅ Links to organization detail page
- ✅ Consistent card styling

### `_form_item.html.erb`

**Purpose:** Card component for displaying an individual form.

- ✅ Shows form name and icon
- ✅ Displays creation time
- ✅ Links to form detail page
- ✅ Matches organization item styling for consistency

### `_task_list.html.erb`

**Purpose:** Special component for task listing with different layout.

- ✅ Shows tasks in a list format rather than cards
- ✅ Includes task details and completion buttons
- ✅ Handles empty state for tasks
- ✅ Uses a more compact layout appropriate for task items

## Usage

These partials are used in the main dashboard view and are driven by the `dashboard_tabs` helper method which defines the configuration for each tab including its content source, styling, and empty state messaging.

### Adding a New Tab Type

1. Add its configuration to the `dashboard_tabs` helper method
2. Create any necessary item partials
3. The existing system will handle rendering it appropriately

### Example Configuration

```erb
<%= render 'shared/home_tabs/tab_content', tab: {
  id: 'example',
  title: 'Example Items',
  count: 5,
  color: 'indigo',
  icon: 'fas fa-star',
  path: examples_path,
  items_method: -> { Example.limit(4) },
  item_partial: 'example_item'
} %>
