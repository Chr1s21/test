module DashboardHelper
  def dashboard_tabs
    [
      {
        id: "organizations",
        title: "My Organizations",
        count: current_user.organisations.count,
        color: "blue",
        icon: "fas fa-building",
        path: organisations_path,
        items_method: -> { current_user.organisations.order(created_at: :desc).limit(4) },
        empty_title: "You don't have any organizations yet",
        empty_description: "Create your first organization to get started",
        action_text: "Create Organization",
        action_path: new_organisation_path,
        item_partial: "organization_item"
      },
      {
        id: "forms",
        title: "Active Forms",
        count: Form.count,
        color: "green",
        icon: "fas fa-file-alt",
        path: forms_path,
        items_method: -> { Form.order(created_at: :desc).limit(4) },
        empty_title: "No active forms available",
        empty_description: "Create a new form to get started",
        action_text: "Create Form",

        item_partial: "form_item"
      },
      {
        id: "tasks",
        title: "Pending Workflows",
        count: 5, # Replace with actual count when implemented
        color: "purple",
        icon: "fas fa-tasks",
        path: "#",
        custom_content: "task_list", # This tab uses custom_content, so no items_method needed
        empty_title: "All caught up!",
        empty_description: "You have no pending tasks at the moment"
      }
      # If you have any other tabs without items_method or custom_content, they need to be fixed
    ]
  end
end
