class ArchivesController < ApplicationController
  before_action :authenticate_user!
  

  def index
    @archives = Flow.joins(:organisation)
    .where(organisation: current_user.organisations)
  end 

  def show
  @flow = Flow.find(params[:id])
  @archives = FormSubmission.joins(:flow).where(flow: @flow.id)

  # Hier nimmst du z. B. die erste Submission aus dem Archiv – oder nutze params[:submission_id] für gezielte Anzeige
  @form_submission = @archives.first

  # Sicherstellen, dass @form für Breadcrumb verfügbar ist
  @form = @form_submission&.form
  end

end