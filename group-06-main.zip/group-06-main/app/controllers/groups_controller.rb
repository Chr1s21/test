class GroupsController < ApplicationController
    before_action :authenticate_user!
    before_action :set_organisation
    before_action :set_group, only: %i[ show edit update destroy add_member remove_member ]
    before_action :require_admin!, only: %i[ edit update destroy add_member remove_member ]
  # …


  def index
    @groups = @organisation.groups
  end

  def show
    # Anzeige der Gruppe; H1 in der View
  end

  def new
    @group = @organisation.groups.build
  end

  def create
    @group = @organisation.groups.build(group_params)
    if @group.save
      redirect_to organisation_group_path(@organisation, @group), notice: "Gruppe angelegt."
    else
      render :new
    end
  end

  def set_organisation
    @organisation = current_user.organisations.find(params[:organisation_id])
  end

  def set_group
    @group = @organisation.groups.find(params[:id])
  end

  def group_params
    params.require(:group).permit(:name)
  end

  def edit
    # Bearbeiten nur für Admins
  end

  def update
    if @group.update(group_params)
      redirect_to organisation_groups_path(@organisation), notice: "Gruppe aktualisiert."
    else
      render :edit
    end
  end

  # app/controllers/groups_controller.rb
  def destroy
    if @group.users.empty?
      @group.destroy
      redirect_to organisation_groups_path(@organisation), notice: "Group deleted successfully"
    else
      redirect_to organisation_groups_path(@organisation),
                  alert: "Cannot delete group - it still has members. Remove all members first."
    end
  end


  # === Mitglieder verwalten ===

  def add_member
    # Inline-Admin-Check ganz oben:
    unless current_user.memberships.find_by(organisation: @organisation)&.admin?
      redirect_to organisation_group_path(@organisation, @group),
                  alert: "Nur Organisations-Admins dürfen Gruppen-Mitglieder verwalten." and return
    end

    user = @organisation.users.find(params[:user_id])
    @group.group_memberships.create!(user: user)
    redirect_to organisation_group_path(@organisation, @group),
                notice: "Nutzer #{user.name} wurde hinzugefügt."
  rescue ActiveRecord::RecordInvalid => e
    redirect_to organisation_group_path(@organisation, @group),
                alert: "Hinzufügen fehlgeschlagen: #{e.record.errors.full_messages.to_sentence}"
  end

  def remove_member
    membership = @group.group_memberships.find_by!(user_id: params[:user_id])
    user       = membership.user
    membership.destroy!
    redirect_to organisation_group_path(@organisation, @group),
                notice: "Nutzer #{user.name} wurde entfernt."
  end


  private

  def require_admin!
    puts "--> require_admin! für Action=#{action_name}, User=#{current_user&.id || 'nil'}"
    unless current_user.memberships.find_by(organisation: @organisation)&.admin?
      redirect_to organisation_group_path(@organisation, @group),
                  alert: "Nur Organisations-Admins dürfen Gruppen-Mitglieder verwalten." and return false
    end
  end
end
