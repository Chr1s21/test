# app/controllers/memberships_controller.rb
class MembershipsController < ApplicationController
  before_action :authenticate_user!
  before_action :set_organisation
  before_action :set_membership, only: %i[update destroy]

  # POST /organisations/:organisation_id/memberships
  def create
    if params[:membership]
      # Admin lädt einen beliebigen User mit Rolle X ein
      unless current_user.admin_of?(@organisation)
        return redirect_to organisation_path(@organisation),
                           alert: "Only admins can perform this action."
      end

      @membership = @organisation.memberships.new(membership_params)
      if @membership.save
        redirect_to organisation_path(@organisation), notice: "Membership created."
      else
        redirect_to organisation_path(@organisation),
                    alert: @membership.errors.full_messages.to_sentence
      end
    else
      # Self-join: Ein Nicht-Admin tritt sich selbst als Member bei
      @membership = @organisation.memberships.new(user: current_user, role: :pending)
      if @membership.save
        redirect_to organisation_path(@organisation), notice: "Your request is pending approval."
      else
        redirect_to organisation_path(@organisation),
                    alert: @membership.errors.full_messages.to_sentence
      end
    end
  end

  # PATCH/PUT /organisations/:organisation_id/memberships/:id
  def update
    unless current_user.admin_of?(@organisation)
      return redirect_to organisation_path(@organisation),
                         alert: "Only admins can perform this action."
    end

    if @membership.update(membership_params)
      redirect_to organisation_path(@organisation), notice: "Membership updated."
    else
      redirect_to organisation_path(@organisation), alert: "Failed to update membership."
    end
  end

  # DELETE /organisations/:organisation_id/memberships/:id
  def destroy
    if current_user.admin_of?(@organisation) || @membership.user == current_user
      @membership.destroy
      redirect_to organisations_path, notice: "Membership deleted."
    else
      redirect_to organisation_path(@organisation),
                  alert: "Only admins can perform this action."
    end
  end

  private

  def set_organisation
    @organisation = Organisation.find(params[:organisation_id])
  end

  def set_membership
    @membership = @organisation.memberships.find(params[:id])
  end

  def membership_params
    params.require(:membership).permit(:user_id, :role)
  end
end
