class FormsController < ApplicationController
  before_action :authenticate_user!
  before_action :set_form, only: [:edit, :update, :destroy, :new]

  def create
    @form = Form.new(name: "Form Title")
    @form.user = current_user
    puts "DEBUG: Current user in controller: #{current_user.inspect}"

    if @form.save
      redirect_to new_form_path(@form)
    else
      puts "DEBUG: Form not saved: #{@form.errors.full_messages}"
      render :new
    end
  end

  def edit
    @fields = @form.fields.order(:position)
    @field = @form.fields.new
  end

  def show
    puts params
    @form_submission = FormSubmission.find(params[:id])
    @form = @form_submission.form
    puts @form
    @fields = @form.fields.order(:position)
    puts @fields
    @responses = @form_submission.field_responses.includes(:field).index_by(&:field_id)
    puts @responses
    @back = @form_submission.flow
  end

  def new 
    @fields = @form.fields.order(:position)
  end

  def index
    @forms = current_user.forms
    puts "DEBUG: Forms in index action: #{@forms.inspect}"
  end

  def destroy
    puts "DEBUG: Destroy action called"
  end

  def update
    @form = Form.find(params[:id])
    @fields = @form.fields.order(:position)  # Add this line to ensure @fields is always set
    
    ActiveRecord::Base.transaction do
      # Temporär alle Positionen auf große negative Werte setzen
      @form.fields.update_all("position = position - 10000")
      
      if @form.update(form_params)
        # Erfolgreich aktualisiert
        redirect_to forms_path, notice: "Form was successfully updated."
      else
        @form.fields.each.with_index(1) do |field, index|
          field.update_column(:position, index)
        end
        
        render :edit, status: :unprocessable_entity, alert: "Form could not be updated."
      end
    end
  end

  private
  def set_form
    @form = Form.find(params[:id])
  end

  def form_params
    params.require(:form).permit(:name, fields_attributes: [:id, :name, :position, :x_position, :y_position])
  end

end