# app/controllers/flows_controller.rb
class FlowsController < ApplicationController
  before_action :set_flow, only: %i[show edit update destroy]
  before_action :authorize_flow_creation, only: %i[new create]

  def index
    @flows = Flow.joins(:organisation)
                 .where(organisation: current_user.organisations)
  end

  def show
  end

  def new
    @flow = Flow.new
  end

  def create
    @flow = Flow.new(flow_params)
    if @flow.save
      redirect_to @flow, notice: "Flow wurde erfolgreich angelegt."
    else
      render :new
    end
  end

  def edit
  end

  def update
    if @flow.update(flow_params)
      redirect_to @flow, notice: "Flow wurde erfolgreich aktualisiert."
    else
      render :edit
    end
  end

  def destroy
    @flow.destroy
    redirect_to flows_path, notice: "Flow wurde gelöscht."
  end

  private

  def set_flow
    @flow = Flow.find(params[:id])
  end

  def authorize_flow_creation
    org = Organisation.find(params.dig(:flow, :organisation_id))
    unless current_user.admin_of?(org) || current_user.organisator_of?(org)
      redirect_to flows_path, alert: "Du bist nicht berechtigt, einen Flow anzulegen."
    end
  end

  def flow_params
    params.require(:flow).permit(
      :organisation_id,
      :recipient_id,
      :status,
      :start_date,
      :done_date,
      form_ids: []
    )
  end
end
