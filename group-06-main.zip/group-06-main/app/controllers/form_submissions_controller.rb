class FormSubmissionsController < ApplicationController
  before_action :authenticate_user!
  before_action :set_form_submission, only: [:show, :edit, :update, :submit]
  
  def index
    @form_submissions = current_user.form_submissions.includes(:form)
  end
  
  def show
  end
  
  def edit
    @form_submission.form.fields.each do |field|
      @form_submission.field_responses.find_or_create_by(field: field)
    end
  end
  
  def update
    # Aktualisiere die Antworten
    if params[:responses].present?
      params[:responses].each do |field_id, value|
        field = Field.find(field_id)
        response = @form_submission.field_responses.find_or_initialize_by(field: field)
        response.value = value
        response.save
      end
    end
    
    if params[:commit] == "Submit"
      success, errors = @form_submission.submit!
      if success
        redirect_to submission_index_path, notice: "Formular erfolgreich abgsendet"
      else
        redirect_to edit_submission_path(@form_submission), alert: "Error submitting form: #{errors.join(', ')}"
      end
    else
      @form_submission.complete!
      redirect_to edit_submission_path(@form_submission), notice: "Formular gespeichert."
    end
  end

  
  def submit
    success, errors = @form_submission.submit!
    
    if success
      redirect_to @form_submission, notice: "Form submitted successfully."
    else
      flash.now[:error] = "Please fix the following errors: #{errors.join(', ')}"
      render :edit
    end
  end
  
  private
  
  def set_form_submission
    @form_submission = current_user.form_submissions.find(params[:id])
    @form = @form_submission.form
    @fields = @form.fields.order(:position)
    @field_responses = @form_submission.field_responses.includes(:field).index_by(&:field_id)
  end
  
  def form_submission_params
    params.require(:form_submission).permit(field_responses_attributes: [:id, :field_id, :value])
  end
end