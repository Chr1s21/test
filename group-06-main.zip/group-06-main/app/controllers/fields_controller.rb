class FieldsController < ApplicationController
  before_action :set_form
  
  def create
    @form = Form.find(params[:form_id])
    @field = @form.fields.new(field_params)
    @field.position = (@form.fields.maximum(:position) || 0) + 1
    
    respond_to do |format|
      if @field.save
        format.html { redirect_back(fallback_location: edit_form_path(@form), notice: 'Field was successfully created.') }
        format.json { render json: { success: true, field: @field }, status: :created }
      else
        format.html do
          @fields = @form.fields.order(:position)
          render "forms/edit", status: :unprocessable_entity
        end
        format.json { render json: { success: false, errors: @field.errors.full_messages }, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    puts "DEBUG: Destroy action called"
    if @form.nil?
      respond_to do |format|
        format.html { redirect_back(fallback_location: root_path, alert: 'Form not found.') }
        format.json { render json: { success: false, error: 'Form not found.' }, status: :not_found }
      end
      return
    end
    
    @field = @form.fields.find_by(id: params[:id])
    puts "DEBUG: Field to delete: #{@field.inspect}"
    
    if @field.nil?
      respond_to do |format|
        format.html { redirect_back(fallback_location: edit_form_path(@form), alert: 'Field not found.') }
        format.json { render json: { success: false, error: 'Field not found.' }, status: :not_found }
      end
      return
    end
    
    if @field.destroy
      respond_to do |format|
        format.html { redirect_back(fallback_location: edit_form_path(@form), notice: 'Field was successfully deleted.') }
        format.json { render json: { success: true, message: 'Field was successfully deleted.' }, status: :ok }
      end
    else
      respond_to do |format|
        format.html { redirect_back(fallback_location: edit_form_path(@form), alert: 'Field could not be deleted.') }
        format.json { render json: { success: false, error: 'Field could not be deleted.' }, status: :unprocessable_entity }
      end
    end
  end

  def edit
  end

  def update
    @form = Form.find(params[:form_id])
    @field = @form.fields.find(params[:id])
    @fields = @form.fields.order(:position)  # Add this line to ensure @fields is always set
  
    if @field.update(field_params)
      redirect_to edit_form_path(@form), notice: "Field was successfully updated."
    else
      render "forms/edit", status: :unprocessable_entity
    end
  end

  private
  
  def field_params
    params.require(:field).permit(:name, :field_type, :position, :required, :regex_type, :value, :x_position, :y_position)
  end

  def set_form
    @form = Form.find(params[:form_id])
  end
end
