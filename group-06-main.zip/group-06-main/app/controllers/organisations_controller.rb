class OrganisationsController < ApplicationController
  # This makes sure that the set organization method runs
  # before the listed commands, everytime those are called.
  before_action :set_organisation, only: %i[show edit update destroy]

  # This makes sure that the user is logged in before running the listed commands.
  before_action :ensure_privileges, only: %i[edit update]

  before_action :ensure_admin, only: %i[destroy]

  before_action :authenticate_user!

  def organisation_params
    params.require(:organisation)
          .permit(:name, :city, :country)
  end


  
  def index
    # 1) alle Orgas, in denen der aktuelle User Mitglied ist
    @organisations = current_user.organisations

    # 2) alle Orgas, in denen er kein Mitglied ist
    @other_organisations = Organisation.where.not(id: @organisations.pluck(:id))
  end


  def show
    @organisation = Organisation.find(params[:id])
    
  end

  # This method will be used to render the create new organization view file.
  # "New"
  def new
    @organisation = Organisation.new
  end

  # This creates a new organization and saves it.
  def create
    @organisation = Organisation.new(organisation_params)
    if @organisation.save
      # Creator zum Admin machen
      @organisation.memberships.create!(
        user: current_user,
        role: :admin
      )
      redirect_to organisation_path(@organisation), notice: "Organisation erstellt und du wurdest als Admin hinzugefügt."
    else
      render :new, status: :unprocessable_entity
    end
  end

  # Shows the edit view for an organization.
  # "Edit"
  def edit
  end

  # Update a organization.
  def update
    if @organisation.update((organisation_params))
      redirect_to @organisation, notice: "Organisation updated successfully."
    else
      Rails.logger.debug "Update failed: #{@organisation.errors.full_messages}"
      render :edit, status: :unprocessable_entity
    end
  end

  def destroy
    @organisation.destroy
    redirect_to organisations_path, notice: "Organisation und alle zugehörigen Datensätze wurden gelöscht."
  end
  private

  # This method sets @organization to the one organization it receives the id for.
  # It receives the id from URL paths, which means that methods in the view files
  # give the id.
  def set_organisation
    @organisation = Organisation.find(params[:id])
  end

  
  def ensure_privileges
    # Sicherstellen, dass current_user vorhanden ist
    unless current_user
      redirect_to new_user_session_path, alert: "Bitte melden Sie sich an."
      return
    end
    
    membership = Membership.find_by(user: current_user, organisation: @organisation)
    
    if membership.nil?
      redirect_to organisations_path, alert: "Sie sind kein Mitglied dieser Organisation."
    elsif !(membership.organisator? || membership.admin?)
      # Hier wird überprüft, ob der Benutzer ein Organisator oder Admin ist
      # und nur dann Zugriff gewährt.
      redirect_to organisations_path, alert: "Zugriff verweigert: Sie sind kein Organisator oder Admin dieser Organisation."
    end
  end

  def ensure_admin
    unless current_user
      redirect_to new_user_session_path, alert: "Bitte melden Sie sich an."
      return
    end

    membership = Membership.find_by(user: current_user, organisation: @organisation)

    if membership.nil? || !membership.admin?
      redirect_to organisations_path, alert: "Zugriff verweigert: Sie sind nicht ein Admin dieser Organisation."
    end
  end
end


