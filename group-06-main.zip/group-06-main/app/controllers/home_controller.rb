# Add the home controller code
class HomeController < ApplicationController
  before_action :authenticate_user!
  
  def index
    # Hole alle Organisationen des Benutzers für die Anzeige
    @organisations = current_user.organisations
  end
end