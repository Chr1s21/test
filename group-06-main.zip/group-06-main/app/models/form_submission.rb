class FormSubmission < ApplicationRecord
  belongs_to :form
  belongs_to :user
  belongs_to :flow
  has_many :field_responses, dependent: :destroy
  has_many :fields, through: :form

  validates :status, inclusion: { in: ['incomplete', 'completed', 'submitted'] }
  validates :user_id, uniqueness: { scope: :form_id, message: "already has a submission for this form" }

  accepts_nested_attributes_for :field_responses


  def complete!
    update!(status: 'completed', completed_at: Time.current)
  end
  
  def submit!
    # Validate before submitting
    errors = validate_responses
    
    if errors.any?
      return [false, errors]
    else
      update!(status: 'submitted', completed_at: Time.current)
      return [true, nil]
    end
  end
  
  def validate_responses
    errors = []
    
    field_responses.includes(:field).each do |response|
      field = response.field
      value = response.value
      
      # Check required fields
      if field.required && (value.nil? || value.empty?)
        errors << "#{field.name} is required"
        next
      end

      if (value.length < 3)
        errors << "#{field.name} is to short"
        next
      end 
      
      next if value.nil? || value.empty?
      
      # Validate based on field type and regex_type
      case field.field_type
      when 'number'
        errors << "#{field.name} must be a number" unless value.to_s =~ /\A[+-]?\d+(\.\d+)?\z/
      when 'date'
        errors << "#{field.name} must be a valid date" unless value.to_s =~ /\A\d{4}-\d{2}-\d{2}\z/
      end
      
      if field.regex_type.present?
        case field.regex_type
        when 'email'
          errors << "#{field.name} must be a valid email" unless value =~ /\A[^@\s]+@[^@\s]+\.[^@\s]+\z/
        when 'url'
          errors << "#{field.name} must be a valid URL" unless value =~ /\A(http|https):\/\/[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,}(:[0-9]{1,5})?(\/.*)?$/ix
        when 'phone'
          errors << "#{field.name} must be a valid phone number" unless value =~ /\A(\+\d{1,3}\s?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}\z/
        end
      end
    end
    
    errors
  end
end
