class GroupMembership < ApplicationRecord
  belongs_to :user
  belongs_to :group

  # Verhindert doppelte Einträge desselben Users in derselben Gruppe
  validates :user_id,
  uniqueness: {
    scope: :group_id,
    message: "User is already a member of this group"
  }

  validate :validate_user_in_organisation

  private

  def validate_user_in_organisation
    # Get the organisation of the group
    organisation = group&.organisation
    
    # Check if the user is a member of that organisation
    if organisation.present? && !Membership.exists?(user: user, organisation: organisation)
      errors.add(:base, "User must be a member of the group's organisation")
    end
  end
end

