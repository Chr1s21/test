class Field < ApplicationRecord
  VALID_TYPES = %w[text date number checkbox].freeze
  REGEX_TYPES = %w[email url phone date].freeze
  

  belongs_to :form
  has_many :field_responses, dependent: :destroy
  validates :name, presence: true, length: { maximum: 30, minimum: 3 }
  validates :field_type, presence: true, inclusion: { in: VALID_TYPES }
  validates :position, numericality: { only_integer: true }, allow_nil: false, uniqueness: { scope: :form_id }
  validates :required, inclusion: { in: [true, false] }, allow_nil: false
  validates :regex_type, inclusion: { in: REGEX_TYPES }, allow_nil: true
end
 
