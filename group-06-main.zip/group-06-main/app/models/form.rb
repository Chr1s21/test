class Form < ApplicationRecord
  has_many :fields, dependent: :destroy
  has_many :form_submissions, dependent: :destroy
  has_many :submitting_users, through: :form_submissions, source: :user
  belongs_to :user # form creator/owner
  validates :name, presence: true, length: { maximum: 30, minimum: 3 }, uniqueness: { scope: :user_id }

  accepts_nested_attributes_for :fields, allow_destroy: true

  # Method to generate submissions for users
  def assign_to_users(users)
    users_array = Array(users)
    new_submissions = []
    
    users_array.each do |user|
      next if form_submissions.exists?(user: user)
      
      submission = form_submissions.create!(
        user: user,
        status: 'incomplete'
      )
      
      fields.each do |field|
        submission.field_responses.create!(field: field, value: nil)
      end
      
      new_submissions << submission
    end
    
    new_submissions
  end
end
