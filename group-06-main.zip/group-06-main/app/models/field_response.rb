class FieldResponse < ApplicationRecord
  belongs_to :form_submission
  belongs_to :field

  validates :field_id, uniqueness: { scope: :form_submission_id }
  
  # Method to help with form building
  def field_name
    "field_responses[#{field_id}][value]"
  end
end
