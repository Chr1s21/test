class Flow < ApplicationRecord
  belongs_to :organisation
  belongs_to :recipient, class_name: "User"

  # has_many :through–Beziehung
  has_many :flow_forms, dependent: :destroy
  has_many :forms, through: :flow_forms
  has_many :form_submissions

  # Status-Enum: alle Werte müssen exakt so geschrieben sein
  enum :status, {
    not_started: 0,
    in_progress: 1,
    feedback:    2,
    done:        3
  }
  

  # Validation – Aufruf mit genau EINEM Argument
  validate :recipient_in_same_organisation

  private

  def recipient_in_same_organisation
    unless organisation.users.exists?(id: recipient_id)
      errors.add(:recipient, 'muss in derselben Organisation sein')
    end
  end
end