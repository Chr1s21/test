class Membership < ApplicationRecord
  belongs_to :user
  belongs_to :organisation

  # Enum für Rollen definieren
  enum :role, { 
    member: 0, 
    organisator: 1, 
    admin: 2 ,
    pending: 3
    }, default: :pending

  # Verhindert doppelte Einträge desselben Users in derselben Organisation
  validates :organisation_id,
    uniqueness: {
      scope: :user_id,
      message: "User is already a member of this organisation"
    }

  # Hilfsmethoden zur Rollenzuweisung
  def make_member!
    update!(role: :member)
  end

  def make_organisator!
    update!(role: :organisator)
  end

  def make_admin!
    update!(role: :admin)
  end

  def make_pending!
    update!(role: :pending)
  end

  after_destroy :destroy_empty_organisation

  private

  def destroy_empty_organisation
    # Läuft nur, wenn die Organisation keine weiteren Memberships mehr hat
    if organisation.memberships.count.zero?
      organisation.destroy
    end
  end
end

