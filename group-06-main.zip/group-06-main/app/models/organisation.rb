class Organisation < ApplicationRecord
  validates :name, presence: true

  
  has_many :flows, dependent: :destroy
  has_many :memberships, dependent: :destroy
  has_many :users, through: :memberships
  has_many :groups, dependent: :destroy
end
