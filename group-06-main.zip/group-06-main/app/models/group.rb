class Group < ApplicationRecord
  validates :name, presence: true
   validate :no_members_before_destroy, on: :destroy
  belongs_to :organisation
  has_many   :group_memberships, dependent: :destroy
  has_many   :users, through: :group_memberships

  private

  def no_members_before_destroy
    if users.any?
      errors.add(:base, "Group cannot be deleted while it still has members")
    end
  end
end
