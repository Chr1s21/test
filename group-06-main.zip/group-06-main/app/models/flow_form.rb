class FlowForm < ApplicationRecord
  belongs_to :flow
  belongs_to :form
  validates :form_id, uniqueness: { scope: :flow_id }
end
