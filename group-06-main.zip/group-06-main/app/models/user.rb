class User < ApplicationRecord
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable

  validates :firstname, :name, presence: true

  # Wichtig: durch das _Plural_-Symbol :memberships
  has_many :memberships,   dependent: :destroy
  has_many :organisations, through: :memberships
  has_many :group_memberships, dependent: :destroy
  has_many :groups, through: :group_memberships
  has_many :forms, dependent: :destroy
  has_many :form_submissions, dependent: :destroy

  def member?(organisation)
    memberships.find_by(organisation: organisation)&.member?
  end

  def organisator?(organisation)
    memberships.find_by(organisation: organisation)&.organisator?
  end

  def admin?(organisation)
    memberships.find_by(organisation: organisation)&.admin?
  end

  def admin_of?(organisation)
    memberships
      .where(organisation_id: organisation.id, role: "admin")
      .exists?
  end

  def organisator_of?(organisation)
    memberships
      .where(organisation_id: organisation.id, role: "organisator")
      .exists?
  end
  
  def member_of?(organisation)
    memberships
      .where(organisation_id: organisation.id, role: "member")
      .exists?
  end

  def full_name
    "#{firstname} #{name}".strip
  end


end
