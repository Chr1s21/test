# GruppenManager

A web application for managing groups and organizations.

## Requirements

* Docker

## Getting Started

Follow these steps to set up the project on your local machine:

### 1. Clone the repository
```bash
git clone https://github.com/your-username/group-06.git
cd group-06

### 2. Docker Setup

# Build the Docker containers
docker compose build

# Start the containers
docker compose up

### 3. Environment setup

# Access the app container shell
docker compose exec app bash

# Install Ruby dependencies
bundle install

# Install JavaScript dependencies
npm install
# OR
yarn install

# Create, migrate and seed the database
bin/rails db:setup
