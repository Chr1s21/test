class CreateRoles < ActiveRecord::Migration[8.0]
  def change
    create_table :roles do |t|
      t.string :name
      t.boolean :admin
      t.boolean :organisator
      t.boolean :member

      t.timestamps
    end
  end
end
