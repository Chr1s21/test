class AddAdminAndOrganisatorToMemberships < ActiveRecord::Migration[8.0]
  def change
    add_column :memberships, :admin, :boolean, default: false, null: false unless column_exists?(:memberships, :admin)
    add_column :memberships, :organisator, :boolean, default: false, null: false unless column_exists?(:memberships, :organisator)
  end
end
