class CreateFieldResponses < ActiveRecord::Migration[8.0]
  def change
    create_table :field_responses do |t|
      t.references :form_submission, null: false, foreign_key: true
      t.references :field, null: false, foreign_key: true
      t.string :value

      t.timestamps
    end

    add_index :field_responses, [:form_submission_id, :field_id], unique: true
  end
end
