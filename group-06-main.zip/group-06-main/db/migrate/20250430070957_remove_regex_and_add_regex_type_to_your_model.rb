class RemoveRegexAndAddRegexTypeToYourModel < ActiveRecord::Migration[8.0]
  def change
    remove_column :fields, :regex, :string
    add_column :fields, :regex_type, :integer
    add_index :fields, :regex_type
  end
end
