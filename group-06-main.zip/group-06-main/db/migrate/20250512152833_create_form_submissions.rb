class CreateFormSubmissions < ActiveRecord::Migration[8.0]
  def change
    create_table :form_submissions do |t|
      t.references :form, null: false, foreign_key: true
      t.references :user, null: false, foreign_key: true
      t.references :flow, null: false, foreign_key: true
      t.string :status
      t.datetime :completed_at

      t.timestamps
    end

    add_index :form_submissions, :status
    add_index :form_submissions, [:form_id, :user_id], unique: true
  end
end
