class DropTablegroupMemberships < ActiveRecord::Migration[8.0]
  def change
    drop_table :group_memberships
  end
end
