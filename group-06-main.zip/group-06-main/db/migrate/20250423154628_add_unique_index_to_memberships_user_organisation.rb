class AddUniqueIndexToMembershipsUserOrganisation < ActiveRecord::Migration[8.0]
  def change
    add_index :memberships,
      %i[user_id organisation_id],
      unique: true,
      name: "index_memberships_on_user_and_organisation"
  end
end
  