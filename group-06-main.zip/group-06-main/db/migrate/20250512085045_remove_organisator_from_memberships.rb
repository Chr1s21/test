class RemoveOrganisatorFromMemberships < ActiveRecord::Migration[8.0]
  def change
    remove_column :memberships, :organisator if column_exists?(:memberships, :organisator)
  end
end
