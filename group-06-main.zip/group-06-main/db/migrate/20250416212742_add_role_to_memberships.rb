class AddRoleToMemberships < ActiveRecord::Migration[8.0]
  def change
    add_reference :memberships, :role, null: false, foreign_key: true
  end
end
