class EnsureMembershipRoleColumn < ActiveRecord::Migration[8.0]
  def up
    # First update any existing NULL values to the default value (3)
    execute("UPDATE memberships SET role = 3 WHERE role IS NULL")
    
    # Then add the NOT NULL constraint and set default
    change_column :memberships, :role,
                  :integer,
                  default: 3,
                  null: false
  end

  def down
    change_column :memberships, :role,
                  :integer,
                  default: nil,
                  null: true
  end
end
