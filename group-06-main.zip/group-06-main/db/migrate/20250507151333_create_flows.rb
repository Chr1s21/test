class CreateFlows < ActiveRecord::Migration[8.0]
  def change
    create_table :flows do |t|
      t.references :organisation, null: false, foreign_key: true
      t.integer    :recipient_id,  null: false
      t.integer    :status,        null: false, default: 0
      t.date       :start_date
      t.date       :done_date

      t.timestamps
    end

    add_foreign_key :flows, :users, column: :recipient_id
    add_index       :flows, :recipient_id
  end
end
