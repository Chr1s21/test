class AddPositionsToFields < ActiveRecord::Migration[8.0]
  def change
    add_column :fields, :x_position, :integer, default: 0
    add_column :fields, :y_position, :integer, default: 0
  end
end
