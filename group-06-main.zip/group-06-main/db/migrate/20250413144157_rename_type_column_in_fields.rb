class RenameTypeColumnInFields < ActiveRecord::Migration[8.0]
  def change
    rename_column :fields, :type, :field_type
  end
end
