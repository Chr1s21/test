class ChangeRegexTypeToFields < ActiveRecord::Migration[8.0]
  def change
    change_column :fields, :regex_type, :string, null: true
  end
end
