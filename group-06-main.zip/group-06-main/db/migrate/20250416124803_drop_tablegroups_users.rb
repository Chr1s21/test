class DropTablegroupsUsers < ActiveRecord::Migration[8.0]
  def change
    drop_table :groups_users
  end
end
