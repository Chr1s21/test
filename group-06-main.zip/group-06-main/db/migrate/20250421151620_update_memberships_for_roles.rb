class UpdateMembershipsForRoles < ActiveRecord::Migration[8.0]
  def change
    # Add a new column 'member' to the memberships table
    add_column :memberships, :member, :boolean, default: false, null: false

    # Remove the foreign key and the role_id column from memberships
    remove_foreign_key :memberships, :roles
    remove_column :memberships, :role_id, :bigint

    # Drop the roles table
    drop_table :roles do |t|
      t.string :name, null: false
      t.boolean :admin
      t.boolean :organisator
      t.boolean :member
      t.datetime :created_at, null: false
      t.datetime :updated_at, null: false
    end
  end
end