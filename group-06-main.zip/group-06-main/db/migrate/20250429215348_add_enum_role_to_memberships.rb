class AddEnumRoleToMemberships < ActiveRecord::Migration[8.0]
  def up
    add_column :memberships, :role, :integer, default: 0

    # Bestehende Daten migrieren
    Membership.reset_column_information
    Membership.find_each do |membership|
      if membership.organisator
        membership.update_column(:role, 1)  # organisator
      else
        membership.update_column(:role, 0)  # member
      end
    end

    # Alte Spalten entfernen
    remove_column :memberships, :member
    remove_column :memberships, :organisator
  end

  def down
    add_column :memberships, :member, :boolean, default: false
    add_column :memberships, :organisator, :boolean, default: false

    # Daten zurücksichern
    Membership.reset_column_information
    Membership.find_each do |membership|
      if membership.role == 'organisator'
        membership.update_columns(organisator: true, member: false)
      else
        membership.update_columns(member: true, organisator: false)
      end
    end

    remove_column :memberships, :role
  end
end
