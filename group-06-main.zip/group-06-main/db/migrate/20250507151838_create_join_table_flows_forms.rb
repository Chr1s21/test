class CreateJoinTableFlowsForms < ActiveRecord::Migration[8.0]
  def change
    create_join_table :flows, :forms do |t|
      t.index [:flow_id, :form_id], unique: true
    end
  end
end
