class CreateFlowForms < ActiveRecord::Migration[8.0]
  def change
    create_table :flow_forms do |t|
      t.references :flow, null: false, foreign_key: true
      t.references :form, null: false, foreign_key: true

      t.timestamps
    end

    add_index :flow_forms, %i[flow_id form_id], unique: true
  end
end
