class DropJoinTableFlowsForms < ActiveRecord::Migration[8.0]
  def change
    drop_table :flows_forms
  end
end
