class AddFalueAndRegexToFields < ActiveRecord::Migration[8.0]
  def change
     add_column :fields, :value, :string
     add_column :fields, :regex, :string
  end
end
