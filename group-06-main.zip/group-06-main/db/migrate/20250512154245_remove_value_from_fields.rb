class RemoveValueFromFields < ActiveRecord::Migration[8.0]
  def change
    remove_column :fields, :value, :string
  end
end
