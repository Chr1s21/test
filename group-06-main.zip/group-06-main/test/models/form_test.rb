require "test_helper"

class FormTest < ActiveSupport::TestCase
  test "valid fixture" do
    assert forms(:form_football).valid?
  end

  test "invalid without name" do
    form = forms(:form_football)
    form.name = nil
    assert_not form.valid?
  end

  test "has many fields" do
    form = forms(:form_football)
    assert_equal 2, form.fields.count
  end

  test "destroying form destroys fields" do
    assert_difference("Field.count", -2) do
      forms(:form_football).destroy
    end
  end

  test "belongs to user" do
    assert_equal users(:alice), forms(:form_football).user
  end

  test "validates name length" do
    form = forms(:form_football)
    form.name = "a" * 31
    assert_not form.valid?
    form.name = "a" * 2
    assert_not form.valid?
    form.name = "a" * 3
    assert form.valid?
  end 

  test "form as json includes fields" do
    json = forms(:form_football).as_json(include: :fields)
    assert_equal forms(:form_football).name, json["name"]
    assert_equal 2, json["fields"].size
  end
end
