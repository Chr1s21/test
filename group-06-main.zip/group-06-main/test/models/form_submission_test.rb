require "test_helper"

class FormSubmissionTest < ActiveSupport::TestCase
  setup do
    @user = users(:alice)
    @form_creator = users(:bob)
    @form = forms(:form_trikot)
    @form.update(user: @form_creator)
    @flow = flows(:flow_football_bob)
    
    @text_field = fields(:field_name)
    @email_field = fields(:field_mail)
    @phone_field = fields(:field_phone)
    @date_field = fields(:field_birthdate)
    
    @form_submission = FormSubmission.create(form: @form, user: @user, flow: @flow, status: 'incomplete')
  end
  
  test "belongs to form" do
    assert_respond_to @form_submission, :form
  end
  
  test "belongs to user" do
    assert_respond_to @form_submission, :user
  end
  
  test "has many field responses" do
    assert_respond_to @form_submission, :field_responses
  end
  
  # Validations
  test "requires a valid status" do
    @form_submission.status = 'invalid'
    assert_not @form_submission.valid?
    
    @form_submission.status = 'incomplete'
    assert @form_submission.valid?
    
    @form_submission.status = 'completed'
    assert @form_submission.valid?
    
    @form_submission.status = 'submitted'
    assert @form_submission.valid?
  end
  
  test "validates uniqueness of user scoped to form" do
    duplicate = FormSubmission.new(form: @form, user: @user)
    assert_not duplicate.valid?
    assert_includes duplicate.errors[:user_id], "already has a submission for this form"
  end
  
  # Instance methods
  test "complete! marks the submission as completed" do
    @form_submission.complete!
    assert_equal 'completed', @form_submission.status
    assert_not_nil @form_submission.completed_at
  end
  
  test "submit! validates and marks the submission as submitted when valid" do
    # Create field responses
    FieldResponse.create(form_submission: @form_submission, field: @text_field, value: 'John Doe')
    FieldResponse.create(form_submission: @form_submission, field: @email_field, value: 'john@example.com')
    FieldResponse.create(form_submission: @form_submission, field: @phone_field, value: '555-123-4567')
    
    success, errors = @form_submission.submit!
    assert success
    assert_nil errors
    assert_equal 'submitted', @form_submission.status
    assert_not_nil @form_submission.completed_at
  end
  
  test "submit! returns errors when responses are invalid" do
    FieldResponse.create(form_submission: @form_submission, field: @text_field, value: '')
    FieldResponse.create(form_submission: @form_submission, field: @email_field, value: 'not-an-email')
    FieldResponse.create(form_submission: @form_submission, field: @phone_field, value: '555-123-4567')
    
    success, errors = @form_submission.submit!
    assert_not success
    assert_includes errors, "Nachname is required"
    assert_includes errors, "E-Mail must be a valid email"
    assert_equal 'incomplete', @form_submission.status
  end
  
  test "validate_responses checks required fields" do
    FieldResponse.create(form_submission: @form_submission, field: @text_field, value: '')
    
    errors = @form_submission.validate_responses
    assert_includes errors, "Nachname is required"
  end
  
  test "validate_responses checks email format" do
    FieldResponse.create(form_submission: @form_submission, field: @text_field, value: 'John')
    FieldResponse.create(form_submission: @form_submission, field: @email_field, value: 'not-an-email')
    
    errors = @form_submission.validate_responses
    assert_includes errors, "E-Mail must be a valid email"
  end
  
  test "validate_responses checks phone format" do
    FieldResponse.create(form_submission: @form_submission, field: @text_field, value: 'John')
    FieldResponse.create(form_submission: @form_submission, field: @email_field, value: 'john@example.com')
    FieldResponse.create(form_submission: @form_submission, field: @phone_field, value: 'not-a-phone')
    
    errors = @form_submission.validate_responses
    assert_includes errors, "Telefonnummer must be a valid phone number"
  end
end
