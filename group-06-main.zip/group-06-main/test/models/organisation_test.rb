require "test_helper"

class OrganisationTest < ActiveSupport::TestCase
  test "create organisation with empty name" do
    organisation = Organisation.new
    assert_not organisation.valid?
    assert_includes organisation.errors[:name], "can't be blank"
  end

  test "create organisation with name" do
    organisation = Organisation.new(name: "VFB Stuttgart")
    assert_equal "VFB Stuttgart", organisation.name
  end


  test "checks which groups the organisation has" do
    organisation = organisations(:fcHeilbronn)
    group = groups(:trainer)
  
    assert_includes organisation.groups, group
  end

  test "groups are destroyed when organization is destroyed" do
    # Create a new organization to avoid breaking other tests
    organisation = Organisation.create!(name: "Temporary Org")
    
    # Create two groups in this organization
    group1 = Group.create!(name: "Group 1", organisation: organisation)
    group2 = Group.create!(name: "Group 2", organisation: organisation)
    
    # Store the IDs for later verification
    group1_id = group1.id
    group2_id = group2.id
    
    # Verify the groups exist
    assert Group.exists?(group1_id)
    assert Group.exists?(group2_id)
    
    # Destroy the organization
    organisation.destroy
    
    # Verify the groups no longer exist
    assert_not Group.exists?(group1_id), "Group 1 should have been destroyed"
    assert_not Group.exists?(group2_id), "Group 2 should have been destroyed"
  end
end
