# require "test_helper"

# class FlowFormTest < ActiveSupport::TestCase
#   fixtures :flow_forms, :flows, :forms

#   test "fixture ist valide" do
#     assert flow_forms(:flow_fcHeilbronn_bob_football).valid?
#   end

#   test "doppelte Zuordnung ist nicht erlaubt" do
#     dup = FlowForm.new(
#       flow: flows(:flow_fcHeilbronn_bob),
#       form: forms(:form_football)
#     )
#     assert_not dup.valid?
#     assert_includes dup.errors[:form_id], "has already been taken"
#   end
# end
