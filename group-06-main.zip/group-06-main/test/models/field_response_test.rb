require "test_helper"

class FieldResponseTest < ActiveSupport::TestCase
    setup do
      @user = users(:alice)
      @form = forms(:form_trikot)
      @field = fields(:field_name)
      @flow = flows(:flow_football_bob)

      @form_submission = FormSubmission.create(form: @form, user: @user, flow: @flow, status: 'incomplete')
      @field_response = FieldResponse.new(form_submission: @form_submission, field: @field, value: 'Test Value')
    end
    
    # Associations
    test "belongs to form_submission" do
      assert_respond_to @field_response, :form_submission
    end
    
    test "belongs to field" do
      assert_respond_to @field_response, :field
    end
    
    # Validations
    test "validates uniqueness of field_id scoped to form_submission_id" do
      @field_response.save!
      duplicate = FieldResponse.new(form_submission: @form_submission, field: @field, value: 'Another Value')
      assert_not duplicate.valid?
    end
    
    # Methods
    test "field_name returns the proper field name for form building" do
      @field_response.save!
      expected_name = "field_responses[#{@field.id}][value]"
      assert_equal expected_name, @field_response.field_name
    end
end
