require "test_helper"

class FlowTest < ActiveSupport::TestCase
  fixtures :flows, :organisations, :users, :forms, :flow_forms

  setup do
    @flow       = flows(:flow_fcHeilbronn_bob)
    @org        = organisations(:fcHeilbronn)
    @bob        = users(:bob)
    @other_user = users(:charlie)
  end

  test "fixture ist valide" do
    assert @flow.valid?
  end

  test "belongs_to organisation und recipient" do
    assert_equal @org, @flow.organisation
    assert_equal @bob, @flow.recipient
  end

  test "enum status funktioniert" do
    @flow.status = :done
    assert @flow.done?
    @flow.status = :feedback
    assert @flow.feedback?
  end

  test "recipient muss in derselben organisation sein" do
    f = Flow.new(organisation: @org, recipient: @other_user, status: :not_started)
    assert f.valid?
  end

  # test "kann mehrere forms über flow_forms haben" do
  #   assert_equal 2, @flow.forms.count
  #   assert_includes @flow.forms, forms(:form_football)
  #   assert_includes @flow.forms, forms(:form_trikot)
  # end
end
