require "test_helper"

class UserTest < ActiveSupport::TestCase
  test "create user with empty name" do
    user = User.new(
      name: nil,
      email: "caty@gmail.com",
      firstname: "caty",
      password: "password123",
      password_confirmation: "password123"
    )
    assert_not user.valid?
    assert_includes user.errors[:name], "can't be blank"
  end

  test "create user with empty email" do
    user = User.new(
      name: "space",
      email: nil,
      firstname: "kevin",
      password: "password123",
      password_confirmation: "password123"
    )
    assert_not user.valid?
    assert_includes user.errors[:email], "can't be blank"
  end

  test "create user with empty firstname" do
    user = User.new(
      name: "tschigerillo",
      email: "tschigerillo@gmail.com",
      firstname: nil,
      password: "password123",
      password_confirmation: "password123"
    )
    assert_not user.valid?
    assert_includes user.errors[:firstname], "can't be blank"
  end

  test "create user with invalid email" do
    user = User.new(
      name: "mayer",
      email: "invalid_email",
      firstname: "hans",
      password: "password123",
      password_confirmation: "password123"
    )
    assert_not user.valid?
    assert_includes user.errors[:email], "is invalid"
  end

  test "create user with duplicate email" do
    User.create!(
      name: "orton",
      email: "randyo@web.de",
      firstname: "randy",
      password: "password123",
      password_confirmation: "password123"
    )

    duplicate_user = User.new(
      name: "ort",
      email: "randyo@web.de",
      firstname: "ranom",
      password: "password123",
      password_confirmation: "password123"
    )

    assert_not duplicate_user.valid?
    assert_includes duplicate_user.errors[:email], "has already been taken"
  end

  test "registration fails if password confirmation does not match" do
    user = User.new(
      name: "marley",
      firstname: "bobby",
      email: "bobby@example.com",
      password: "password123",
      password_confirmation: "wrongpassword"
    )
    assert_not user.valid?
    assert_includes user.errors[:password_confirmation], "doesn't match Password"
  end

  test "registration fails without password" do
    user = User.new(
      name: "bridget",
      firstname: "cassy",
      email: "charlie@example.com"
      # kein Passwort
    )
    assert_not user.valid?
    assert_includes user.errors[:password], "can't be blank"
  end

  test "user registration succeeds with valid data" do
    user = User.new(
      name: "lester",
      firstname: "bridget",
      email: "bg@example.com",
      password: "password123",
      password_confirmation: "password123"
    )
    assert user.valid?
    assert user.save
  end


  test "does Alice have the admin role in fcHeilbronn" do
    user = users(:alice)
    organisation = organisations(:fcHeilbronn)
    membership = Membership.find_by(user: user, organisation: organisation)
    assert_equal true, membership.admin?
  end
  
  test "admin_of? returns true for admins" do
    user         = users(:alice)
    organisation = organisations(:fcHeilbronn)
    assert user.admin_of?(organisation), "Alice sollte Admin in fcHeilbronn sein"
  end

  test "admin_of? returns false for non-admins" do
    user         = users(:charlie)
    organisation = organisations(:fcHeilbronn)
    assert_not user.admin_of?(organisation), "Charlie sollte kein Admin in fcHeilbronn sein"
  end
end
