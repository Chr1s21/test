require "test_helper"

class GroupMembershipTest < ActiveSupport::TestCase
  setup do
    @user = users(:alice)
    @group = groups(:trainer)


    @organisation = organisations(:fcHeilbronn)
  end
  
  test "valid group membership" do
    membership = group_memberships(:alice_trainer)
    assert membership.valid?

    user = User.create!(
      firstname: "John",
      name: "Doe",
      email: "john.doe@example.com", 
      password: "password123" 
    )

    group = Group.create!(
      name: "Test Group",
      organisation: @organisation,
    )

    Membership.create!(
      user_id: user.id,
      organisation_id: @organisation.id,
      role: :member
    )

    membership = GroupMembership.new(user: user, group: group)
    assert membership.valid?
  end

  test "requires user" do
    membership = GroupMembership.new(group: @group)
    assert_not membership.valid?
    assert_includes membership.errors[:user], "must exist"
  end

  test "requires group" do
    membership = GroupMembership.new(user: @user)
    assert_not membership.valid?
    assert_includes membership.errors[:group], "must exist"
  end

  test "prevents duplicate memberships" do
    # Try to create duplicate
    duplicate = GroupMembership.new(user: @user, group: @group)
    assert_not duplicate.valid?
    assert_includes duplicate.errors[:user_id], "User is already a member of this group"
  end

  test "allows same user in different groups" do
    group1 = groups(:ajugend)
    group2 = groups(:bjugend)
    
    membership1 = GroupMembership.create(user: @user, group: group1)
    membership2 = GroupMembership.new(user: @user, group: group2)
    
    assert membership1.valid?
    assert membership2.valid?
  end

  test "allows different users in same group" do
    user1 = users(:alice)
    user2 = users(:bob)

    group = groups(:bjugend)
    
    membership1 = GroupMembership.new(user: user1, group: group)
    membership2 = GroupMembership.new(user: user2, group: group)
    
    assert membership1.valid?
    assert membership2.valid?
  end

  test "validates user belongs to group's organisation" do
    # Create a user not in the organisation
    outside_user = User.new(
      firstname: "Dooby",
      name: "Brown",
      email: "exp@web.de",
      password: "password123",
    ) 
    
    # Create a membership with that user
    membership = GroupMembership.new(user: outside_user, group: @group)
    
      assert_not membership.valid?
      assert_includes membership.errors.full_messages, "User must be a member of the group's organisation"
    
  end

  test "destroying user destroys group memberships" do
    
    assert_difference "GroupMembership.count", -1 do
      @user.destroy
    end
  end

  test "destroying group destroys group memberships" do
    
    assert_difference "GroupMembership.count", -3 do
      @group.destroy
    end
  end

  test "all fixture group memberships are valid" do
    # Iterate through all group memberships in fixtures
    GroupMembership.all.each do |membership|
      assert membership.valid?, "Group membership for user #{membership.user.name} in group #{membership.group.name} is invalid: #{membership.errors.full_messages.join(', ')}"
    end
  end
  
end
