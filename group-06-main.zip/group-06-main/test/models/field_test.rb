require "test_helper"

class FieldTest < ActiveSupport::TestCase
  test "valid fixture" do
    assert fields(:field_firstname).valid?
  end

  test "invalid without name" do
    field = fields(:field_firstname)
    field.name = nil
    assert_not field.valid?
  end

  test "invalid without type" do
    field = fields(:field_firstname)
    field.field_type = nil
    assert_not field.valid?
  end

  test "position must be integer" do
    field = fields(:field_firstname)
    field.position = "abc"
    assert_not field.valid?
  end

  test "belongs to form" do
    field = fields(:field_firstname)
    assert_equal forms(:form_football), field.form
  end

  test "validates name length" do
    field = fields(:field_firstname)
    field.name = "a" * 31
    assert_not field.valid?
    field.name = "a" * 2
    assert_not field.valid?
    field.name = "a" * 3
    assert field.valid?
  end 

  test "position is unique per form" do
    field = fields(:field_name).dup
    field.name = "Neues Feld"
    assert_not field.valid?
  end

  test "invalid with unknown field type" do
    field = fields(:field_name)
    field.field_type = "not_a_valid_type"
    assert_not field.valid?
  end

  test "validates required field with valid credentials" do
    field = fields(:field_firstname)
    assert field.valid?
    field.required = false
    assert field.valid?
  end

  test "invalid with empty required field" do
    field = fields(:field_firstname)
    field.required = nil
    assert_not field.valid?
  end

  test "validates regex type" do
    field = fields(:field_firstname)
    field.regex_type = "email"
    assert field.valid?
    field.regex_type = "url"
    assert field.valid?
    field.regex_type = "phone"
    assert field.valid?
    field.regex_type = "date"
    assert field.valid?
  end

  test "invalid with unknown regex type" do
    field = fields(:field_firstname)
    field.regex_type = "not_a_valid_regex_type"
    assert_not field.valid?
  end
end
