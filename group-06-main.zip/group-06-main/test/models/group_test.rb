require "test_helper"

class GroupTest < ActiveSupport::TestCase 
  fixtures :users, :groups, :organisations, :group_memberships
  
  test "list users in group" do
    group = groups(:trainer)     # Gruppe aus fixtures
    alice = users(:alice)         # User Alice aus fixtures
    
    assert_includes group.users, alice
  end

  test "group belongs to correct organisation" do
    organisation = organisations(:fcHeilbronn)
    group = groups(:trainer)
  
    assert_equal organisation, group.organisation
  end

  test "user bob aus gruppe a_jugend entfernen" do
    group = groups(:trainer)  # muss in groups.yml definiert sein
    user = users(:jeff)

    assert_includes group.users, user

    group.users.delete(user)
    group.reload

    refute_includes group.users, user
  end
end
