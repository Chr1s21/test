require "test_helper"

class MembershipTest < ActiveSupport::TestCase
  fixtures :users, :organisations, :memberships
  setup do
  @membership = memberships(:alice_fcHeilbronn) # Beispielmitgliedschaft aus Fixtures
  end


  test "user darf nicht zwei mal in der gleichen organisation sein" do
    user         = users(:alice)
    organisation = organisations(:fcHeilbronn)

    # Per fixtures gibt es bereits eine Membership für (alice, fcHeilbronn)
    dup = Membership.new(
      user:         user,
      organisation: organisation,
    )

    assert_not dup.valid?
    assert_includes dup.errors[:organisation_id], "User is already a member of this organisation"
  end

  test "count memberships for fcHeilbronn" do
    assert_equal 4, organisations(:fcHeilbronn).memberships.count
  end

  test "membership should have role attribute" do
    assert_respond_to @membership, :role
    assert_respond_to @membership, :organisator?
    assert_respond_to @membership, :member?
  end
  
  test "member attribute should default to true" do
    membership = memberships(:charlie_fcHeilbronn)
    assert membership.member?
  end

  test "organisator attribute should default to false" do
    assert_not @membership.organisator?
  end

  test "should enforce single role" do
    # Keine Notwendigkeit, da Enum automatisch eine Rolle erzwingt
    @membership.role = :organisator
    assert_not @membership.member?
    assert @membership.organisator?
    
    @membership.role = :member
    assert_not @membership.organisator?
    assert @membership.member?
  end

  test "member membership should be valid" do
    @membership.role = :member
    assert @membership.valid?
  end

  test "organisator membership should be valid" do
    @membership.role = :organisator 
    assert @membership.valid?
  end

  test "The Fixture is set up right" do
    find_by_user_and_organisation = Membership.find_by(user: users(:alice), organisation: organisations(:fcHeilbronn))
    assert_equal find_by_user_and_organisation, @membership
  end

test "requires user" do
  membership = Membership.new(organisation: organisations(:fcHeilbronn))
  assert_not membership.valid?
  assert_includes membership.errors[:user], "must exist"
end

test "requires organisation" do
  membership = Membership.new(user: users(:alice))
  assert_not membership.valid?
  assert_includes membership.errors[:organisation], "must exist"
end

test "allows user to be member in multiple organisations" do
  user = users(:alice)
  org1 = organisations(:fcHeilbronn)
  org2 = organisations(:hochzeit)
  
  # Alice should already be a member of fcHeilbronn from fixtures
  membership1 = Membership.find_by(user: user, organisation: org1)
  assert membership1.present?
  
  # Create a new membership for Alice in dcHeilbronn
  membership2 = Membership.new(user: user, organisation: org2, role: :member)
  assert membership2.valid?
end

test "allows multiple users in same organisation" do
  org = organisations(:fcHeilbronn)
  user1 = users(:alice)
  user2 = users(:bob)
  
  # Both users should already have memberships from fixtures
  membership1 = Membership.find_by(user: user1, organisation: org)
  membership2 = Membership.find_by(user: user2, organisation: org)
  
  assert membership1.present?
  assert membership2.present?
  assert_not_equal membership1, membership2
end

test "destroying user destroys memberships" do
  user = User.create!(
    firstname: "Temporary", 
    name: "User", 
    email: "temp_user@example.com", 
    password: "password"
  )
  
  org = organisations(:fcHeilbronn)
  Membership.create!(user: user, organisation: org, role: :member)
  
  assert_difference "Membership.count", -1 do
    user.destroy
  end
end

test "destroying organisation destroys memberships" do
  org = Organisation.create!(name: "Temporary Org")
  user = users(:alice)
  
  Membership.create!(user: user, organisation: org, role: :member)
  
  assert_difference "Membership.count", -1 do
    org.destroy
  end
end

test "can change role of existing membership" do
  membership = memberships(:alice_fcHeilbronn)
  
  # Ensure it starts as one role
  membership.update!(role: :member)
  assert membership.member?
  assert_not membership.organisator?
  
  # Check that we can change to another role
  membership.update!(role: :organisator)
  assert membership.organisator?
  assert_not membership.member?
end

test "can create valid membership with different roles" do
  user = User.create!(
    firstname: "New", 
    name: "Member", 
    email: "new.member@example.com", 
    password: "password"
  )
  
  org = Organisation.create!(name: "New Org")
  
  member_membership = Membership.new(user: user, organisation: org, role: :member)
  assert member_membership.valid?
  
  organizer_membership = Membership.new(user: user, organisation: org, role: :organisator)
  assert organizer_membership.valid?
  
  # Only one can be saved due to uniqueness validation
  assert member_membership.save
  
  # If we try to save the second one, it should fail
  assert_not organizer_membership.save
  assert_includes organizer_membership.errors[:organisation_id], "User is already a member of this organisation"
end
end