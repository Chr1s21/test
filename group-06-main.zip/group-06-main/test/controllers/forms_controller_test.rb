require "test_helper"

class FormsControllerTest < ActionDispatch::IntegrationTest
  include Devise::Test::IntegrationHelpers

  setup do
    @user = users(:alice)
    @form = forms(:form_trikot)
    sign_in @user
  end 

  test "should create new form with default name and redirect to edit" do    
    assert_difference('Form.count') do
      post forms_path
    end
    
    new_form = Form.last
    assert_redirected_to new_form_path(new_form)
  end

  test "should associate new form with current user" do
    post forms_path
    new_form = Form.last
    assert_equal @user.id, new_form.user.id
  end
  
  test "should create form with default name 'Neues Formular'" do
    post forms_path
    new_form = Form.last
    assert_equal "Form Title", new_form.name
  end
  
  test "should not create form when user is not signed in" do
    sign_out @user
    assert_no_difference('Form.count') do
      post forms_path
    end
    assert_redirected_to new_user_session_path
  end

  test 'should update form name' do
    patch form_path(@form), params: { form: { name: 'Updated Form' } }
    @form.reload
    assert_equal 'Form was successfully updated.', flash[:notice]
    assert_redirected_to forms_path
  end

  test 'should not update form with invalid name' do
    patch form_path(@form), params: { form: { name: '' } }
    @form.reload
    assert_not_equal '', @form.name
    assert_template :edit
  end

  test 'should not update form with invalid id' do
    patch form_path(-1), params: { form: { name: 'Updated Form' } }
    assert_response :not_found
  end
end
