# test/controllers/memberships_controller_test.rb
require "test_helper"

class MembershipsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @organisation    = organisations(:fcHeilbronn)
    @admin           = users(:alice)
    @member_bob      = users(:bob)
    @charlie_member  = users(:charlie)
    @new_user        = users(:new_user)
  end

  # Admins can create arbitrary memberships with a given role
  test "admin can create membership with role" do
    sign_in(@admin)

    assert_difference("Membership.count", 1) do
      post organisation_memberships_url(@organisation),
           params: { membership: { user_id: @new_user.id, role: "organisator" } }
    end

    assert_redirected_to organisation_url(@organisation)
    assert_equal "organisator", Membership.last.role
    assert_equal @new_user.id, Membership.last.user_id
  end

  # Non-admins may not assign roles or add other users
  test "non-admin cannot create membership for another user" do
    sign_in(@member_bob)

    assert_no_difference("Membership.count") do
      post organisation_memberships_url(@organisation),
           params: { membership: { user_id: @new_user.id, role: "organisator" } }
    end

    assert_redirected_to organisation_url(@organisation)
    assert_equal "Only admins can perform this action.", flash[:alert]
  end

  # Any non-member may join as pending
  test "non-member can join organisation as pending" do
    sign_in(@new_user)

    assert_difference("Membership.count", 1) do
      post organisation_memberships_url(@organisation)
    end

    m = Membership.order(:created_at).last
    assert_equal @new_user.id, m.user_id
    assert_equal "pending", m.role
    assert_redirected_to organisation_url(@organisation)
    assert_equal "Your request is pending approval.", flash[:notice]
  end

  # Non-admins cannot update roles
  test "non-admin cannot update membership" do
    sign_in(@member_bob)
    membership = memberships(:charlie_fcHeilbronn)

    patch organisation_membership_url(@organisation, membership),
          params: { membership: { role: "admin" } }

    assert_redirected_to organisation_url(@organisation)
    assert_equal "Only admins can perform this action.", flash[:alert]
    assert_not_equal "admin", membership.reload.role
  end

  # Admins can change roles
  test "admin can update membership role" do
    sign_in(@admin)
    membership = memberships(:charlie_fcHeilbronn)

    patch organisation_membership_url(@organisation, membership),
          params: { membership: { role: "admin" } }

    assert_redirected_to organisation_url(@organisation)
    assert_equal "Membership updated.", flash[:notice]
    assert_equal "admin", membership.reload.role
  end

  # A member may leave (destroy) their own membership
  test "member can destroy own membership" do
    sign_in(@charlie_member)
    membership = memberships(:charlie_fcHeilbronn)

    assert_difference("Membership.count", -1) do
      delete organisation_membership_url(@organisation, membership)
    end

    assert_redirected_to organisations_url
    assert_equal "Membership deleted.", flash[:notice]
  end

  # Non-admins may not remove other users
  test "non-admin cannot destroy other's membership" do
    sign_in(@member_bob)
    membership = memberships(:charlie_fcHeilbronn)

    assert_no_difference("Membership.count") do
      delete organisation_membership_url(@organisation, membership)
    end

    assert_redirected_to organisation_url(@organisation)
    assert_equal "Only admins can perform this action.", flash[:alert]
  end

  # Admins can remove any membership
  test "admin can destroy membership" do
    sign_in(@admin)
    membership = memberships(:bob_fcHeilbronn)

    assert_difference("Membership.count", -1) do
      delete organisation_membership_url(@organisation, membership)
    end

    assert_redirected_to organisations_url
    assert_equal "Membership deleted.", flash[:notice]
  end
end
