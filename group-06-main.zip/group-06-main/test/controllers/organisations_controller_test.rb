require "test_helper"

class OrganisationsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @fc_hn_organisation = organisations(:fcHeilbronn)
    @user = users(:alice)
    @membership = Membership.find_by(user: @user,organisation: @fc_hn_organisation)
    @membership.make_organisator!
    sign_in @user
  end


test "should get index" do
    get organisations_url
    assert_response :success
  end

  test "should get show" do
    get organisation_url(@fc_hn_organisation)
    assert_response :success
  end

  test "should get new" do
    get new_organisation_url
    assert_response :success
  end

  test "Create a new organisation" do
    assert_difference("Organisation.count") do
      post organisations_url, params: { organisation: { name: "OrgA" } }
    end

    assert_redirected_to organisation_path(Organisation.last)
  end

  test "Name parameter can not be empty" do
    assert_no_difference("Organisation.count") do
      post organisations_url, params: { organisation: { name: "" } }
    end

    assert_response :unprocessable_entity
  end

  test "should get edit" do
    get edit_organisation_url(@fc_hn_organisation)
    assert_response :success
  end

  test "Update an organization" do
    patch organisation_url(@fc_hn_organisation), params: { organisation: { name: "OrgOne1-1" } }

    assert_redirected_to organisation_path(@fc_hn_organisation)
    @fc_hn_organisation.reload
    assert_equal "OrgOne1-1", @fc_hn_organisation.name
  end

  test "Do not allow empty name in update" do
    patch organisation_url(@fc_hn_organisation), params: { organisation: { name: "" } }

    assert_response :unprocessable_entity
    assert_template :edit
    @fc_hn_organisation.reload
    
    assert_not_equal "", @fc_hn_organisation.name
  end



  test "Destroy organisation" do
    
    orgb = Organisation.create(name: "OrgB")

    initial_count = Organisation.count
    

    # Membership mit Organisator-Rechten erstellen
    Membership.create!(user: @user, organisation: orgb, role: :admin)

    assert_difference("Organisation.count", -1) do
      delete organisation_url(orgb)
    end

    assert_redirected_to organisations_path

    # For debugging
    Rails.logger.debug "Current count: #{Organisation.count}"

    assert_equal initial_count - 1, Organisation.count
  end


  test "Multiple organizations are in the index" do
    initial_count = Organisation.count

    orgb = Organisation.create(name: "OrgB")
    orgc = Organisation.create(name: "OrgC37")

    get organisations_url

    assert_response :success

    assert_equal initial_count + 2, Organisation.count

  end

  test "should allow organisator to edit organisation" do
    get edit_organisation_url(@fc_hn_organisation)
    assert_response :success
  end

  test "should deny non-organisator to edit organisation" do
    @membership.update(role: :member) # Change role to member
    get edit_organisation_url(@fc_hn_organisation)
    assert_redirected_to organisations_path
    assert_equal "Zugriff verweigert: Sie sind kein Organisator oder Admin dieser Organisation.", flash[:alert]
  end

  test "admin can access edit" do
    @membership.make_admin!
    get edit_organisation_url(@fc_hn_organisation)
    assert_response :success
  end
  
  test "non-admin cannot access edit" do
    @membership.make_member!
    get edit_organisation_url(@fc_hn_organisation)
    assert_redirected_to organisations_path
  end

end


