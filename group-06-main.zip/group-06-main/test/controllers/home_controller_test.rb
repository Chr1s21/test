require "test_helper"

class HomeControllerTest < ActionDispatch::IntegrationTest
  include Devise::Test::IntegrationHelpers
  
  setup do
    # Create and sign in a user before running the tests
    @user = users(:alice)  # Assumes you have a fixture for users
    # OR create a user directly
    # @user = User.create!(email: "test@example.com", password: "password", firstname: "Test", lastname: "User")
    sign_in @user
  end

  test "should get index" do
    get root_url  # Use root_url if that's your home page route
    assert_response :success
    assert_select "h1", text: /Welcome.+!/  # Check for welcome text
  end
  
  test "should redirect to sign in if not authenticated" do
    sign_out @user
    get root_url
    assert_redirected_to new_user_session_path
  end
end
