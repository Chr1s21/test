require "test_helper"

class GroupsControllerTest < ActionDispatch::IntegrationTest
  include Devise::Test::IntegrationHelpers
  # fixtures added
  fixtures :users, :memberships, :organisations, :groups, :group_memberships

  setup do
    @organisation = organisations(:fcHeilbronn)
    @group        = groups(:trainer)
    @member       = users(:charlie)
    @admin        = users(:alice)

    @other_user   = users(:bob)
    @jeff         = users(:jeff)
  end

  test "non-admin cannot add member" do
    sign_in @member

    assert_no_difference "@group.group_memberships.count" do
      post add_member_organisation_group_path(@organisation, @group),
           params: { user_id: @other_user.id }
    end

    assert_redirected_to organisation_group_path(@organisation, @group)
    assert_equal "Nur Organisations-Admins dürfen Gruppen-Mitglieder verwalten.", flash[:alert]
  end

  test "admin can add member" do
    sign_in @admin

    assert_difference "@group.group_memberships.count", +1 do
      post add_member_organisation_group_path(@organisation, @group),
           params: { user_id: @other_user.id }
    end

    assert_redirected_to organisation_group_path(@organisation, @group)
    assert_equal "Nutzer #{@other_user.name} wurde hinzugefügt.", flash[:notice]
  end

  test "non-admin cannot remove member" do
    sign_in @member
    assert_no_difference "@group.group_memberships.count" do
      delete remove_member_organisation_group_path(@organisation, @group, @jeff.id)
    end

    assert_redirected_to organisation_group_path(@organisation, @group)
    assert_equal "Nur Organisations-Admins dürfen Gruppen-Mitglieder verwalten.", flash[:alert]
  end

  test "admin can remove member" do
    sign_in @admin
    assert_difference "@group.group_memberships.count", -1 do
      delete remove_member_organisation_group_path(@organisation, @group, @jeff.id)
    end

    assert_redirected_to organisation_group_path(@organisation, @group)
    assert_equal "Nutzer #{@jeff.name} wurde entfernt.", flash[:notice]
  end

 test "Admin sieht 'Neue Gruppe anlegen' und Aktionen" do
  sign_in @admin

  get organisation_groups_url(@organisation)
  assert_response :success

  # Link zum Anlegen einer neuen Gruppe prüfen
  assert_select "a[href=?]", new_organisation_group_path(@organisation), text: "Create New Group"

  @organisation.groups.each do |group|
    # Gruppenname vorhanden
    assert_select "td", text: group.name

    # Bearbeiten-Link vorhanden
    assert_select "a[href=?]", edit_organisation_group_path(@organisation, group), text: "Edit"

    if group.users.empty?
      # Für leere Gruppen: button_to mit method: :delete prüfen
      assert_select "form[action=?][method=post]", organisation_group_path(@organisation, group) do
        assert_select "input[name=_method][value=delete]"
        assert_select "button", text: "Delete"
      end
    else
      # Für Gruppen mit Mitgliedern: deaktivierten Button prüfen
      assert_select "button[disabled]", text: "Delete"
    end
  end
  end

  test "Nicht-Admin sieht nur 'Ansehen'-Link" do
    sign_in @member

    # HTTP-Request auf Index
    get organisation_groups_url(@organisation)
    assert_response :success

    # Nur 'Ansehen'-Link, keine Bearbeiten-/Löschen-Links
    assert_select "a[href=?]", organisation_group_path(@organisation, @group), text: "View"
    assert_select "a", text: "Bearbeiten", count: 0
    assert_select 'a[data-method="delete"]', count: 0
  end
end
