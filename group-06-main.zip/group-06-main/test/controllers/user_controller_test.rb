require "test_helper"

class UserControllerTest < ActionDispatch::IntegrationTest
  include Devise::Test::IntegrationHelpers

  setup do
    @user = users(:charlie)
    sign_in @user
  end

  test "user can authenticate with valid credentials" do
    user = User.create!(
      name: "authuser",
      firstname: "tester",
      email: "auth@example.com",
      password: "password123",
      password_confirmation: "password123"
    )

    authenticated = user.valid_password?("password123")
    assert authenticated, "User should be authenticated with valid credentials"
  end

  test "user cannot authenticate with invalid password" do
    user = User.create!(
      name: "authuser",
      firstname: "tester",
      email: "auth@example.com",
      password: "password123",
      password_confirmation: "password123"
    )

    authenticated = user.valid_password?("wrongpassword")
    assert_not authenticated, "User should not be authenticated with an invalid password"
  end

  test "user can change password" do
      new_password = "supersecret123"

      @user.password = new_password
      @user.password_confirmation = new_password
      @user.save!

      puts "New password for #{@user.email}: #{new_password}"

      assert @user.valid?
  end

  test "change only email and output it" do
    new_email = "new_email@example.com"

    @user.email = new_email
    @user.save!

    puts "User new email: #{new_email}"

    assert_equal new_email, @user.reload.email
  end

  test "delete user" do
    assert_difference("User.count", -1) do
      @user.destroy
    end

    assert_not User.exists?(@user.id), "User should be deleted"
  end

  test "user can update name" do
    new_name = "Updated Name"

    @user.name = new_name
    @user.save!

    assert_equal new_name, @user.reload.name

    puts "User updated name: #{new_name}"
  end

  test "user can update firstname" do
    new_firstname = "Updated Firstname"

    @user.firstname = new_firstname
    @user.save!

    assert_equal new_firstname, @user.reload.firstname

    puts "User updated firstname: #{new_firstname}"
  end
end
