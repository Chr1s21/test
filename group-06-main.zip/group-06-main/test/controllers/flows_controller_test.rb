require "test_helper"

class FlowsControllerTest < ActionController::TestCase
  include Devise::Test::ControllerHelpers
  fixtures :flows, :organisations, :users, :forms

  setup do
    @org         = organisations(:fcHeilbronn)
    @bob         = users(:bob)
    @admin       = users(:alice)
    @organisator = users(:jeff)
    @form        = forms(:form_football)
    @valid_attrs = {
      organisation_id: @org.id,
      recipient_id:    @bob.id,
      status:          "not_started",
      start_date:      "2025-05-01",
      done_date:       "2025-05-10",
      form_ids:        [@form.id]
    }
  end

  test "index zeigt nur eigene flows" do
    sign_in @bob

    get :index
    assert_response :success
    assigns(:flows).each do |flow|
      assert_includes @bob.organisations, flow.organisation
    end
  end

  test "admin kann flow anlegen" do
    sign_in @admin

    assert_difference "Flow.count", 1 do
      post :create, params: { flow: @valid_attrs }
    end
    assert_redirected_to flow_path(Flow.last)
  end

  test "organisator kann flow anlegen" do
    sign_in @organisator

    assert_difference "Flow.count", 1 do
      post :create, params: { flow: @valid_attrs }
    end
    assert_redirected_to flow_path(Flow.last)
  end

  test "member darf keinen flow anlegen" do
    sign_in @bob

    assert_no_difference "Flow.count" do
      post :create, params: { flow: @valid_attrs }
    end
    assert_redirected_to flows_path
    assert_equal "Du bist nicht berechtigt, einen Flow anzulegen.", flash[:alert]
  end
end
