require "test_helper"

class FieldsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @form = forms(:form_football) 
    @field_attributes = { 
      name: 'New Field', 
      field_type: 'text',
    }
    @field_attributesNoName = {
      name: 'New Field 2',
    }
    @field_date = {
      name: 'New Field 3',
      field_type: 'date',
    }
    @field_number = {
      name: 'New Field 4',
      field_type: 'number',
    }
    @field_checkbox = {
      name: 'New Field 5',
      field_type: 'checkbox',
    }
    
    # Sign in a test user
    @user = users(:alice)
    sign_in @user
  end

  test "should create text field" do
    assert_difference('Field.count') do
      post form_fields_path(@form), params: { field: @field_attributes }
    end

    assert_redirected_to edit_form_path(@form)
    assert_equal 'Field was successfully created.', flash[:notice]
  end

  test "should not create text field with invalid name" do
    assert_no_difference('Field.count') do
      post form_fields_path(@form), params: { field: {name: "", field_type: "text"} }
    end
    assert_no_difference('Field.count') do
      post form_fields_path(@form), params: { field: { name: 'ab', field_type: 'text' } }
    end
    assert_no_difference('Field.count') do
      post form_fields_path(@form), params: { field: { name: 'a' * 31, field_type: 'text' } }
    end
  end

  test "should not create text field with invalid type" do
    assert_no_difference('Field.count') do
      post form_fields_path(@form), params: { field: { name: 'New Field', field_type: 'invalid_type' } }
    end
  end

  test "should not create text field for invalide form" do
    assert_no_difference('Field.count') do
      post form_fields_path(-1), params: { field: @field_attributes }
    end
  end

  test "should create multiple fields" do
    assert_difference('Field.count', 2) do
      post form_fields_path(@form), params: { field: @field_attributes }
      post form_fields_path(@form), params: { field: @field_attributes }
    end

    assert_redirected_to edit_form_path(@form)
    assert_equal 'Field was successfully created.', flash[:notice]
  end

  test "should create date field" do
    assert_difference('Field.count') do
      post form_fields_path(@form), params: { field: @field_date }
    end

    assert_redirected_to edit_form_path(@form)
    assert_equal 'Field was successfully created.', flash[:notice]
  end

  test "should create number field" do
    assert_difference('Field.count') do
      post form_fields_path(@form), params: { field: @field_number }
    end

    assert_redirected_to edit_form_path(@form)
    assert_equal 'Field was successfully created.', flash[:notice]
  end

  test "should create checkbox field" do
    assert_difference('Field.count') do
      post form_fields_path(@form), params: { field: @field_checkbox }
    end

    assert_redirected_to edit_form_path(@form)
    assert_equal 'Field was successfully created.', flash[:notice]
  end

  test "should delete field with valid id" do
    field = fields(:field_firstname)
    assert_difference('Field.count', -1) do
      delete form_field_path(@form, field)
    end

    assert_equal 'Field was successfully deleted.', flash[:notice]
  end 

  test "should not delete field with invalid id" do
    assert_no_difference('Field.count') do
      delete form_field_path(@form, -1)
    end

    assert_equal 'Field not found.', flash[:alert]
    assert_redirected_to edit_form_path(@form)
  end

  test "should update required attribut" do 
    @field = fields(:field_firstname)
    patch form_field_path(@form, @field), params: { field: { required: false } }

    assert_redirected_to edit_form_path(@form)
    assert_equal 'Field was successfully updated.', flash[:notice]
    assert_equal false, @field.reload.required
  end

  test "should not update required attribut" do
    @field = fields(:field_firstname)
    patch form_field_path(@form, @field), params: { field: { required: nil } }

    assert_response :unprocessable_entity
    assert_not_equal false, @field.reload.required
    assert_equal true, @field.reload.required
  end

  test "should set field regex type as email" do
    @field = fields(:field_firstname)
    patch form_field_path(@form, @field), params: { field: { regex_type: 'email' } }

    assert_redirected_to edit_form_path(@form)
    assert_equal 'Field was successfully updated.', flash[:notice]
    assert_equal 'email', @field.reload.regex_type
  end

  test "should not set field regex type as invalid" do
    @field = fields(:field_firstname)
    patch form_field_path(@form, @field), params: { field: { regex_type: 'invalid_regex' } }

    assert_response :unprocessable_entity
    assert_not_equal 'invalid_regex', @field.reload.regex_type
  end

  test "should set value for field with valid regex" do
    @field = fields(:field_firstname)
    patch form_field_path(@form, @field), params: { field: { regex_type: 'email'}}
    
    assert_redirected_to edit_form_path(@form)
    assert_equal 'Field was successfully updated.', flash[:notice]
    assert_equal 'email', @field.reload.regex_type
  end

  test "set regex type first and then invalide value" do
    @field = fields(:field_firstname)
    patch form_field_path(@form, @field), params: { field: { regex_type: 'email' } }

    assert_redirected_to edit_form_path(@form)
    assert_equal 'email', @field.reload.regex_type
  end
end

