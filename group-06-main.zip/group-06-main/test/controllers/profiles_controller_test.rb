require "test_helper"

class ProfilesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @user = users(:alice)
    sign_in @user
  end


  test "should get show" do
    get profile_path
    assert_response :success
  end

  test "should get edit" do
    get edit_profile_path
    assert_response :success
  end

  test "User should be able to change name" do
    patch profile_path(@user), params: { user: { firstname: "Alice 2" } }
    assert_redirected_to profile_path
  end

end
